package kurztech.com.kin_music_player_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
