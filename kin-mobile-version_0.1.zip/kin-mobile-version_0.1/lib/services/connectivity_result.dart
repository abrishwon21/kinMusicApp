
enum ConnectivityStatus{
  wifi,
  cellular,
  offline
}